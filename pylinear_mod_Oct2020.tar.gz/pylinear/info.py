__author__='Russell Ryan'
__code__='pyLINEAR'
__email__='rryan@stsci.edu'
__ref__='https://ui.adsabs.harvard.edu/abs/2018PASP..130c4501R/abstract'
__version__='2.0'



