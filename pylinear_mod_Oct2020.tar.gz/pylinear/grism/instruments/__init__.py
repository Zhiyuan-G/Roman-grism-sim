from .config import Config
from .load_detector import load_detector

