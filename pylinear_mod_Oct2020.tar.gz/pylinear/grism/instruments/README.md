| Telescope | Instrument | Detector | Device      |
| --------- | ---------- | -------- | ----------- |
| HST       | WFC3       | IR       |             |
| HST       | WFC3       | UVIS     | UVIS1,UVIS2 |
| HST       | ACS        | WFC      | WFC1,WFC2   |
| JWST      | NIRCam     | Long     | modA,modB   |
| JWST      | NIRISS     |          |             |
| RST       | WFI        |          | sca01,...   |
