from .instruments import load_detector
from .grism import GrismImage
from .grismcollection import GrismCollection
from . import config
