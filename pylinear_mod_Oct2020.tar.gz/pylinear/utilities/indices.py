import numpy as np
#from numba import njit

ONE=np.uint(1)

#@njit
def compress(indices):
    unique_indices=np.unique(indices)
    compressed_indices=np.digitize(indices,unique_indices)-1
    return compressed_indices,unique_indices

#@njit
def unique(indices):
    #indexes = np.unique(indices, return_index=True)[1]
    #unique_indices=[indices[index] for index in sorted(indexes)]
    #for ii,jj in zip(indices,unique_indices):
    #    print(ii,jj)
    idx = np.unique(indices, return_index=True)[1]
    unique_indices=indices[np.sort(idx)]
    return unique_indices

#@njit
def decimate(indices,values):
    compressed_indices,unique_indices=compress(indices)
    decimated_values=np.bincount(compressed_indices,weights=values)
    return decimated_values,unique_indices

#@njit
def average(indices,values):
    compressed_indices,unique_indices=compress(indices)
    decimated_values=np.bincount(compressed_indices,weights=values)
    decimated_counts=np.bincount(compressed_indices)
    decimated_values=decimated_values/decimated_counts    
    return decimated_values,unique_indices

#@njit
def reverse(integers):
    uniq,ind,nums=np.unique(integers,return_inverse=True,return_counts=True)
    reverse=np.split(np.argsort(ind),np.cumsum(nums[:-1]))
    #ri=list(zip(uniq,reverse))
    ri=dict(list(zip(uniq,reverse)))
    return ri

#@njit
def one2two(xy,dim):
    y,x=np.divmod(np.array(xy), dim[0])
    return x,y

#@njit
def two2one(x,y,dim):
    return np.array(x) + dim[0] * np.array(y)

#@njit
def unique_pairs(x,y):

    mx=np.amax(x)+1
    shape=(mx.astype(np.int),)

    xy=two2one(x.astype(np.int),y.astype(np.int),shape)

    #xx,yy=one2two(xy,shape) 
    
    xyq=unique(xy) 

    xq,yq=one2two(xyq,shape)
        
    return xq.astype(x.dtype),yq.astype(y.dtype)


if __name__=='__main__':

    x=np.array([1,2,3,4,5,3,1],dtype=np.uint64)
    y=np.array([2,3,4,5,3,4,2],dtype=np.uint64)

    
    xq,yq=unique_pairs(x,y)
    
