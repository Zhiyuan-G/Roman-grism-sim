# change this based on the brightness of the sources
FLUXSCALE=1e-17
FLUXUNIT='erg/s/cm2/A'
