```
File
  Detector
    Beam
      pdts
         (1,1) [DATASET]
         (1,2) [DATASET]
      pmts
         (4,5) [DATASET]
         (6,3) [DATASET] 
      ovt [DATASET]
```
      	